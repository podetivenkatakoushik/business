

// Refreshed file content
// --- Phase 1: Business Intelligence Logic ---

// Static Market Data (Mock)
export const MARKET_DATA: Record<string, { avgPrice: number, volatility: number, demand: string, competition: string }> = {
    'USA': { avgPrice: 120, volatility: 3, demand: 'High', competition: 'High' },
    'UK': { avgPrice: 110, volatility: 4, demand: 'Medium', competition: 'High' },
    'Germany': { avgPrice: 115, volatility: 2, demand: 'High', competition: 'Medium' },
    'India': { avgPrice: 80, volatility: 6, demand: 'Very High', competition: 'High' },
    'China': { avgPrice: 85, volatility: 5, demand: 'Very High', competition: 'Very High' },
    'Japan': { avgPrice: 130, volatility: 2, demand: 'Medium', competition: 'Medium' },
    'Australia': { avgPrice: 125, volatility: 3, demand: 'Medium', competition: 'Medium' },
    'Canada': { avgPrice: 118, volatility: 3, demand: 'Medium', competition: 'Medium' },
    'Brazil': { avgPrice: 90, volatility: 7, demand: 'High', competition: 'Medium' },
    'Global': { avgPrice: 100, volatility: 5, demand: 'Medium', competition: 'Medium' }
};

function getMarketIntelligence(country: string) {
    return MARKET_DATA[country] || MARKET_DATA['Global'];
}

function calculateRiskScore(profitMargin: number, breakEvenMonths: number, marketVolatility: number): number {
    let score = 5; // Base score

    // Profit Margin Impact
    if (profitMargin < 10) score += 3;
    else if (profitMargin < 20) score += 1;
    else if (profitMargin > 40) score -= 2;

    // Break-even Impact
    if (breakEvenMonths > 24) score += 2;
    else if (breakEvenMonths > 12) score += 1;
    else if (breakEvenMonths < 6 && breakEvenMonths > 0) score -= 1;

    // Market Volatility Impact (1-10 scale)
    // Higher volatility increases risk
    if (marketVolatility > 7) score += 2;
    else if (marketVolatility > 5) score += 1;
    else if (marketVolatility < 3) score -= 1;

    // Clamp score between 1 and 10
    return Math.max(1, Math.min(10, score));
}

function generateRecommendations(
    margin: number, 
    risk: number, 
    breakEven: number, 
    price: number, 
    marketPrice: number
): string[] {
    const recs: string[] = [];

    // Pricing Strategy
    if (price > marketPrice * 1.2) {
        recs.push("Price is significantly above market average. Ensure premium value proposition.");
    } else if (price < marketPrice * 0.8) {
        recs.push("Price is well below market average. Potential to increase margins.");
    }

    // Margin Strategy
    if (margin < 15) {
        recs.push("Margins are tight. Focus on reducing variable costs (manufacturing/shipping).");
    } else if (margin > 50) {
        recs.push("Strong margins. Consider reinvesting in marketing to capture market share.");
    }

    // Risk Management
    if (risk >= 8) {
        recs.push("CRITICAL: High business risk. Re-evaluate fixed costs and pricing model.");
    } else if (risk <= 3) {
        recs.push("Low risk profile. Good foundation for scaling operations.");
    }

    // Break-even
    if (breakEven > 18) {
        recs.push("Long ROI period. Consider leasing equipment instead of buying to lower setup costs.");
    }

    return recs;
}

/**
 * Calculate financial metrics for a given set of inputs.
 * @param {Object} inputs
 * @param {number} inputs.manufacturingCost
 * @param {number} inputs.sellingExpense
 * @param {number} inputs.initialSetupCost
 * @param {number} inputs.monthlyFixedCost
 * @param {number} inputs.sellingPrice
 * @param {number} inputs.monthlySalesVolume
 * @returns {Object} Calculated metrics
 */
export function calculateFinancials(inputs: {
    manufacturingCost: number;
    sellingExpense: number;
    initialSetupCost: number;
    monthlyFixedCost: number;
    sellingPrice: number;
    monthlySalesVolume: number;
    country?: string;
}) {
    const { manufacturingCost, sellingExpense, initialSetupCost, monthlyFixedCost, sellingPrice, monthlySalesVolume, country } = inputs;

    // 1. Total Variable Cost per Unit
    const totalVariableCostPerUnit = manufacturingCost + sellingExpense;

    // 2. Profit per Unit
    const profitPerUnit = sellingPrice - totalVariableCostPerUnit;

    // 3. Profit Margin (%)
    const profitMargin = sellingPrice > 0
        ? (profitPerUnit / sellingPrice) * 100
        : 0;

    // 4. Monthly Revenue
    const monthlyRevenue = sellingPrice * monthlySalesVolume;

    // 5. Monthly Variable Cost
    const monthlyVariableCost = totalVariableCostPerUnit * monthlySalesVolume;

    // 6. Monthly Net Profit
    const monthlyNetProfit = monthlyRevenue - monthlyVariableCost - monthlyFixedCost;

    // 7. Break-even Analysis
    let breakEvenValue: number = 0;
    let breakEvenLabel: string = "No Break-even Possible";
    let isLongRecovery = false;

    if (monthlyNetProfit > 0) {
        const months = initialSetupCost / monthlyNetProfit;
        breakEvenValue = months;
        
        if (months < 1) {
            const days = Math.ceil(months * 30);
            breakEvenLabel = `${days} Day${days !== 1 ? 's' : ''}`;
        } else {
            breakEvenLabel = `${round(months)} Month${round(months) !== 1 ? 's' : ''}`;
        }

        if (months > 24) {
            isLongRecovery = true;
        }
    }

    // 8. Minimum Profitable Selling Price
    const minProfitableSellingPrice = monthlySalesVolume > 0
        ? totalVariableCostPerUnit + (monthlyFixedCost / monthlySalesVolume)
        : 0;

    // Break-even Units (Fixed Costs / (Selling Price - Variable Cost))
    const breakEvenUnits = (sellingPrice - totalVariableCostPerUnit) > 0
        ? Math.ceil(monthlyFixedCost / (sellingPrice - totalVariableCostPerUnit))
        : Infinity;

    // 9. Market Intelligence & Risk Analysis
    const marketInfo = getMarketIntelligence(country || 'Global');
    const riskScore = calculateRiskScore(profitMargin, breakEvenValue, marketInfo.volatility);
    const recommendations = generateRecommendations(profitMargin, riskScore, breakEvenValue, sellingPrice, marketInfo.avgPrice);

    return {
        totalVariableCostPerUnit: round(totalVariableCostPerUnit),
        profitPerUnit: round(profitPerUnit),
        profitMargin: round(profitMargin),
        monthlyRevenue: round(monthlyRevenue),
        monthlyVariableCost: round(monthlyVariableCost),
        monthlyFixedCost: round(monthlyFixedCost),
        monthlyNetProfit: round(monthlyNetProfit),
        breakEvenValue, // Numeric value in months for sorting/comparison if needed
        breakEvenLabel, // Formatted string
        isLongRecovery,
        minProfitableSellingPrice: round(minProfitableSellingPrice),
        breakEvenUnits,
        riskLevel: determineRisk(profitMargin),
        // Phase 1: BI Metrics
        marketInfo,
        riskScore,
        recommendations
    };
}

/**
 * Determine risk level based on profit margin.
 * @param {number} margin - Profit margin percentage.
 * @returns {'Low'|'Medium'|'High'|'Critical'}
 */
export function determineRisk(margin: number) {
    if (margin > 20) return 'Low';
    if (margin >= 10) return 'Medium';
    if (margin >= 0) return 'High';
    return 'Critical';
}

/**
 * Format a number as currency (USD).
 * @param {number} value
 * @returns {string}
 */
export function formatCurrency(value: number) {
    const absValue = Math.abs(value);
    const prefix = value < 0 ? '-' : '';

    if (absValue >= 1000000) {
        return prefix + '$' + (absValue / 1000000).toFixed(2) + 'M';
    }
    if (absValue >= 1000) {
        return prefix + '$' + absValue.toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }
    return prefix + '$' + absValue.toFixed(2);
}

/**
 * Format a number as a percentage.
 * @param {number} value
 * @returns {string}
 */
export function formatPercent(value: number) {
    return value.toFixed(2) + '%';
}

/**
 * Round to 2 decimal places.
 * @param {number} value
 * @returns {number}
 */
export function round(value: number) {
    return Math.round(value * 100) / 100;
}

/**
 * List of countries for the dropdown.
 */
export const COUNTRIES = Object.keys(MARKET_DATA).filter(k => k !== 'Global').sort();
