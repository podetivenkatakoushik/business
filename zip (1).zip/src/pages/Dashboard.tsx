import React, { useState, useRef, useEffect } from 'react';
// Refreshed file content
import { calculateFinancials, formatCurrency, formatPercent, COUNTRIES } from '../utils/calculations';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend, BarChart, Bar, ReferenceLine } from 'recharts';
import { Trash2, Plus, MapPin } from 'lucide-react';

interface DashboardProps {
    onNavigate: (page: string) => void;
}

interface LocationInput {
    id: string;
    country: string;
    city: string;
    initialSetupCost: string;
    monthlyFixedCost: string;
}

interface FinancialMetrics {
    totalVariableCostPerUnit: number;
    profitPerUnit: number;
    profitMargin: number;
    monthlyRevenue: number;
    monthlyVariableCost: number;
    monthlyFixedCost: number;
    monthlyNetProfit: number;
    breakEvenValue: number;
    breakEvenLabel: string;
    isLongRecovery: boolean;
    minProfitableSellingPrice: number;
    breakEvenUnits: number;
    riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
    marketInfo: { avgPrice: number, volatility: number, demand: string, competition: string };
    riskScore: number;
    recommendations: string[];
}

interface LocationResult {
    id: string;
    label: string;
    metrics: FinancialMetrics;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [isScrolled, setIsScrolled] = useState(false);
    
    // Global Product Inputs
    const [manufacturingCost, setManufacturingCost] = useState<string>('');
    const [sellingExpense, setSellingExpense] = useState<string>('');
    const [sellingPrice, setSellingPrice] = useState<string>('');
    const [monthlyVolume, setMonthlyVolume] = useState<string>('');
    
    // Locations State
    const [locations, setLocations] = useState<LocationInput[]>([
        { id: '1', country: '', city: '', initialSetupCost: '', monthlyFixedCost: '' }
    ]);

    const [results, setResults] = useState<LocationResult[] | null>(null);
    const [bestLocationId, setBestLocationId] = useState<string | null>(null);
    const [chartData, setChartData] = useState<any[]>([]);
    const [pieData, setPieData] = useState<any[]>([]);
    const [marketChartData, setMarketChartData] = useState<any[]>([]);

    const resultsRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleScroll = () => {
            if (window.scrollY > 30) {
                setIsScrolled(true);
            } else {
                setIsScrolled(false);
            }
        };

        window.addEventListener('scroll', handleScroll, { passive: true });
        handleScroll();

        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const addLocation = () => {
        const newId = (locations.length + 1).toString() + Date.now().toString();
        setLocations([...locations, { id: newId, country: '', city: '', initialSetupCost: '', monthlyFixedCost: '' }]);
    };

    const removeLocation = (id: string) => {
        if (locations.length > 1) {
            setLocations(locations.filter(loc => loc.id !== id));
        }
    };

    const updateLocation = (id: string, field: keyof LocationInput, value: string) => {
        setLocations(locations.map(loc => 
            loc.id === id ? { ...loc, [field]: value } : loc
        ));
    };

    const handleCalculate = (e: React.FormEvent) => {
        e.preventDefault();

        const mCost = parseFloat(manufacturingCost) || 0;
        const sExpense = parseFloat(sellingExpense) || 0;
        const sPrice = parseFloat(sellingPrice) || 0;
        const mVolume = parseInt(monthlyVolume) || 0;

        if (sPrice <= 0) {
            alert('Please enter a valid selling price greater than 0.');
            return;
        }

        // Calculate for each location
        const calculatedResults: LocationResult[] = locations.map(loc => {
            const iSetup = parseFloat(loc.initialSetupCost) || 0;
            const mFixed = parseFloat(loc.monthlyFixedCost) || 0;

            const inputs = { 
                manufacturingCost: mCost, 
                sellingExpense: sExpense, 
                initialSetupCost: iSetup,
                monthlyFixedCost: mFixed,
                sellingPrice: sPrice, 
                monthlySalesVolume: mVolume,
                country: loc.country
            };

            const metrics = calculateFinancials(inputs);
            const label = loc.city && loc.country ? `${loc.city}, ${loc.country}` : `Location ${locations.indexOf(loc) + 1}`;

            return {
                id: loc.id,
                label,
                metrics
            };
        });

        // Find Best Location (Highest Monthly Net Profit)
        let maxProfit = -Infinity;
        let bestId = null;

        calculatedResults.forEach(res => {
            if (res.metrics.monthlyNetProfit > maxProfit) {
                maxProfit = res.metrics.monthlyNetProfit;
                bestId = res.id;
            }
        });

        setResults(calculatedResults);
        setBestLocationId(bestId);

        // Generate Chart Data (Profit vs Selling Price for the BEST location)
        // If multiple locations, we could show multiple lines, but for simplicity let's show the best one or the first one.
        // Let's show the Best Location's curve.
        const bestResult = calculatedResults.find(r => r.id === bestId) || calculatedResults[0];
        
        const data = [];
        const range = 0.5; // +/- 50%
        const startPrice = sPrice * (1 - range);
        const endPrice = sPrice * (1 + range);
        const steps = 10;
        const stepSize = (endPrice - startPrice) / steps;
        
        // Re-calculate inputs for the graph based on the best location
        const bestLocInput = locations.find(l => l.id === bestResult.id);
        const bestISetup = parseFloat(bestLocInput?.initialSetupCost || '0');
        const bestMFixed = parseFloat(bestLocInput?.monthlyFixedCost || '0');

        for (let i = 0; i <= steps; i++) {
            const price = startPrice + (i * stepSize);
            const r = calculateFinancials({ 
                manufacturingCost: mCost, 
                sellingExpense: sExpense, 
                initialSetupCost: bestISetup,
                monthlyFixedCost: bestMFixed,
                sellingPrice: price, 
                monthlySalesVolume: mVolume 
            });
            data.push({
                price: parseFloat(price.toFixed(2)),
                profit: r.monthlyNetProfit
            });
        }
        setChartData(data);

        // Generate Pie Data (Cost Breakdown for Best Location)
        setPieData([
            { name: 'Monthly Variable Cost', value: bestResult.metrics.monthlyVariableCost },
            { name: 'Monthly Fixed Cost', value: bestResult.metrics.monthlyFixedCost }
        ]);

        // Generate Market Comparison Data
        setMarketChartData([
            { name: 'Your Price', price: sPrice, fill: '#4F46E5' },
            { name: 'Market Avg', price: bestResult.metrics.marketInfo.avgPrice, fill: '#9CA3AF' }
        ]);

        // Scroll to results on mobile
        if (window.innerWidth < 768 && resultsRef.current) {
            setTimeout(() => {
                resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }, 100);
        }
    };

    const COLORS = ['#4F46E5', '#10B981', '#F59E0B', '#EF4444'];

    return (
        <>
            {/* ========== NAVBAR ========== */}
            <nav className={`navbar ${isScrolled ? 'scrolled' : ''}`} id="navbar">
                <div className="container navbar-inner">
                    <a href="#" onClick={(e) => { e.preventDefault(); onNavigate('landing'); }} className="logo">
                        <svg className="logo-icon" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect width="32" height="32" rx="8" fill="url(#logo-grad-d)" />
                            <path d="M10 22V10h4l4 6 4-6h4v12h-4v-7l-4 5-4-5v7h-4z" fill="white" />
                            <defs>
                                <linearGradient id="logo-grad-d" x1="0" y1="0" x2="32" y2="32">
                                    <stop stopColor="#4F46E5" />
                                    <stop offset="1" stopColor="#7C3AED" />
                                </linearGradient>
                            </defs>
                        </svg>
                        <span>DecisionEngine</span>
                    </a>
                    <div className={`nav-links ${isMobileMenuOpen ? 'active' : ''}`} id="nav-links">
                        <a href="#" onClick={(e) => { e.preventDefault(); onNavigate('landing'); }}>Home</a>
                        <a href="#" className="btn btn-primary btn-sm">Dashboard</a>
                    </div>
                    <button 
                        className={`mobile-menu-btn ${isMobileMenuOpen ? 'active' : ''}`} 
                        id="mobile-menu-btn" 
                        aria-label="Toggle menu"
                        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                    >
                        <span></span><span></span><span></span>
                    </button>
                </div>
            </nav>

            {/* ========== DASHBOARD ========== */}
            <div className="dashboard-page">
                <div className="dashboard-header">
                    <div className="container">
                        <h1>Financial Calculator</h1>
                        <p>Phase 0: Pure Calculation & Rule-Based Analysis</p>
                    </div>
                </div>

                <div className="container">
                    <div className="dashboard-content">
                        {/* ===== INPUT FORM ===== */}
                        <div className="form-panel">
                            <h2>Financial Inputs</h2>
                            <form id="calculator-form" autoComplete="off" onSubmit={handleCalculate}>
                                
                                <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-4 mt-2">Global Product Costs</h3>
                                <div className="form-group">
                                    <label htmlFor="manufacturing-cost">Manufacturing Cost per Unit ($)</label>
                                    <input 
                                        type="number" 
                                        id="manufacturing-cost" 
                                        placeholder="e.g. 50" 
                                        min="0" 
                                        step="0.01"
                                        required
                                        value={manufacturingCost}
                                        onChange={(e) => setManufacturingCost(e.target.value)}
                                    />
                                </div>
                                <div className="form-group">
                                    <label htmlFor="selling-expense">Selling Expense per Unit ($)</label>
                                    <input 
                                        type="number" 
                                        id="selling-expense" 
                                        placeholder="e.g. 15" 
                                        min="0" 
                                        step="0.01"
                                        required
                                        value={sellingExpense}
                                        onChange={(e) => setSellingExpense(e.target.value)}
                                    />
                                </div>
                                <div className="form-group">
                                    <label htmlFor="selling-price">Expected Selling Price per Unit ($)</label>
                                    <input 
                                        type="number" 
                                        id="selling-price" 
                                        placeholder="e.g. 100" 
                                        min="0" 
                                        step="0.01" 
                                        required
                                        value={sellingPrice}
                                        onChange={(e) => setSellingPrice(e.target.value)}
                                    />
                                </div>
                                <div className="form-group">
                                    <label htmlFor="monthly-volume">Expected Monthly Sales Volume</label>
                                    <input 
                                        type="number" 
                                        id="monthly-volume" 
                                        placeholder="e.g. 1000" 
                                        min="0" 
                                        step="1" 
                                        required
                                        value={monthlyVolume}
                                        onChange={(e) => setMonthlyVolume(e.target.value)}
                                    />
                                </div>

                                <div className="form-divider"></div>

                                <div className="flex items-center justify-between mb-4">
                                    <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-0">Locations</h3>
                                    <button 
                                        type="button" 
                                        onClick={addLocation}
                                        className="text-sm flex items-center gap-1 text-indigo-600 font-semibold hover:text-indigo-800"
                                    >
                                        <Plus size={16} /> Add Location
                                    </button>
                                </div>

                                <div className="space-y-6">
                                    {locations.map((loc, index) => (
                                        <div key={loc.id} className="bg-gray-50 p-4 rounded-lg border border-gray-200 relative">
                                            <div className="flex justify-between items-center mb-3">
                                                <h4 className="font-semibold text-gray-700 flex items-center gap-2">
                                                    <MapPin size={16} /> Location {index + 1}
                                                </h4>
                                                {locations.length > 1 && (
                                                    <button 
                                                        type="button" 
                                                        onClick={() => removeLocation(loc.id)}
                                                        className="text-red-500 hover:text-red-700 p-1"
                                                        title="Remove Location"
                                                    >
                                                        <Trash2 size={16} />
                                                    </button>
                                                )}
                                            </div>
                                            
                                            <div className="form-row">
                                                <div className="form-group mb-0">
                                                    <label htmlFor={`country-${loc.id}`} className="text-xs">Country</label>
                                                    <select 
                                                        id={`country-${loc.id}`}
                                                        value={loc.country}
                                                        onChange={(e) => updateLocation(loc.id, 'country', e.target.value)}
                                                        className="text-sm"
                                                    >
                                                        <option value="">Select</option>
                                                        {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
                                                    </select>
                                                </div>
                                                <div className="form-group mb-0">
                                                    <label htmlFor={`city-${loc.id}`} className="text-xs">City</label>
                                                    <input 
                                                        type="text" 
                                                        id={`city-${loc.id}`}
                                                        placeholder="City" 
                                                        value={loc.city}
                                                        onChange={(e) => updateLocation(loc.id, 'city', e.target.value)}
                                                        className="text-sm"
                                                    />
                                                </div>
                                            </div>
                                            <div className="form-row mt-3">
                                                <div className="form-group mb-0">
                                                    <label htmlFor={`setup-${loc.id}`} className="text-xs">Initial Setup ($)</label>
                                                    <input 
                                                        type="number" 
                                                        id={`setup-${loc.id}`}
                                                        placeholder="0.00" 
                                                        min="0" 
                                                        step="0.01"
                                                        required
                                                        value={loc.initialSetupCost}
                                                        onChange={(e) => updateLocation(loc.id, 'initialSetupCost', e.target.value)}
                                                        className="text-sm"
                                                    />
                                                </div>
                                                <div className="form-group mb-0">
                                                    <label htmlFor={`fixed-${loc.id}`} className="text-xs">Monthly Fixed ($)</label>
                                                    <input 
                                                        type="number" 
                                                        id={`fixed-${loc.id}`}
                                                        placeholder="0.00" 
                                                        min="0" 
                                                        step="0.01"
                                                        required
                                                        value={loc.monthlyFixedCost}
                                                        onChange={(e) => updateLocation(loc.id, 'monthlyFixedCost', e.target.value)}
                                                        className="text-sm"
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>

                                <button type="submit" className="btn btn-primary btn-lg mt-8" style={{ width: '100%' }} id="calculate-btn">
                                    Calculate Financials
                                </button>
                            </form>
                        </div>

                        {/* ===== RESULTS PANEL ===== */}
                        <div className="results-panel" id="results-panel" ref={resultsRef}>
                            {!results ? (
                                <div className="results-empty" id="results-empty">
                                    <div className="results-empty-icon">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                            <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
                                            <polyline points="17 6 23 6 23 12" />
                                        </svg>
                                    </div>
                                    <h3>No results yet</h3>
                                    <p>Fill in your financial inputs and click "Calculate" to see the analysis.</p>
                                </div>
                            ) : (
                                <div id="results-content">
                                    
                                    {/* Global Warnings (based on first result as product costs are global) */}
                                    {results[0].metrics.profitPerUnit < 0 && (
                                        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6 flex items-center gap-3">
                                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                                            <strong>Warning:</strong> Selling price is below cost. Loss per unit.
                                        </div>
                                    )}
                                    {results[0].metrics.profitMargin > 30 && (
                                        <div className="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-3 rounded mb-6 flex items-center gap-3">
                                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                                            <strong>Note:</strong> High profit margin – check market competitiveness.
                                        </div>
                                    )}

                                    <div className={`results-cards-grid ${results.length > 1 ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-2' : ''}`}>
                                        {results.map((result) => {
                                            const isBest = result.id === bestLocationId && results.length > 1;
                                            const profitClass = result.metrics.monthlyNetProfit >= 0 ? 'positive' : 'negative';
                                            
                                            return (
                                                <div key={result.id} className={`results-card ${isBest ? 'best-location' : ''}`} style={{ animationDelay: '0.1s' }}>
                                                    <div className="results-card-header">
                                                        <div className="results-card-title flex flex-col">
                                                            <span>{result.label}</span>
                                                            {isBest && <span className="best-badge mt-1 w-fit">Most Profitable Option</span>}
                                                        </div>
                                                        <span className={`risk-badge risk-${result.metrics.riskLevel.toLowerCase()}`}>
                                                            {result.metrics.riskLevel} Risk
                                                        </span>
                                                    </div>
                                                    
                                                    {result.metrics.monthlyNetProfit < 0 && (
                                                        <div className="text-xs text-orange-600 bg-orange-50 p-2 rounded mb-4 border border-orange-100">
                                                            ⚠️ Operating at monthly loss
                                                        </div>
                                                    )}

                                                    {result.metrics.isLongRecovery && (
                                                        <div className="text-xs text-amber-600 bg-amber-50 p-2 rounded mb-4 border border-amber-100">
                                                            ⚠️ Long investment recovery period
                                                        </div>
                                                    )}

                                                    <div className="results-metrics">
                                                        <div className="metric-card">
                                                            <div className="metric-label">Monthly Net Profit</div>
                                                            <div className={`metric-value ${profitClass}`}>{formatCurrency(result.metrics.monthlyNetProfit)}</div>
                                                        </div>
                                                        <div className="metric-card">
                                                            <div className="metric-label">Break-even</div>
                                                            <div className="metric-value text-lg">{result.metrics.breakEvenLabel}</div>
                                                        </div>
                                                        <div className="metric-card">
                                                            <div className="metric-label">Monthly Fixed Cost</div>
                                                            <div className="metric-value">{formatCurrency(result.metrics.monthlyFixedCost)}</div>
                                                        </div>
                                                        <div className="metric-card">
                                                            <div className="metric-label">Profit Margin</div>
                                                            <div className={`metric-value ${result.metrics.profitMargin >= 0 ? 'positive' : 'negative'}`}>{formatPercent(result.metrics.profitMargin)}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>

                                    {/* Graphs Section (Showing Best Location Data) */}
                                    <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
                                        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                                            <h3 className="text-lg font-bold text-gray-900 mb-4">📈 Profit vs Selling Price {results.length > 1 ? '(Best Option)' : ''}</h3>
                                            <div className="h-64">
                                                <ResponsiveContainer width="100%" height="100%">
                                                    <LineChart data={chartData}>
                                                        <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                                                        <XAxis 
                                                            dataKey="price" 
                                                            label={{ value: 'Selling Price ($)', position: 'insideBottom', offset: -5 }} 
                                                            tick={{fontSize: 12}}
                                                        />
                                                        <YAxis 
                                                            label={{ value: 'Net Profit ($)', angle: -90, position: 'insideLeft' }} 
                                                            tick={{fontSize: 12}}
                                                        />
                                                        <Tooltip formatter={(value: number) => formatCurrency(value)} />
                                                        <Line type="monotone" dataKey="profit" stroke="#4F46E5" strokeWidth={2} dot={false} />
                                                    </LineChart>
                                                </ResponsiveContainer>
                                            </div>
                                        </div>

                                        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                                            <h3 className="text-lg font-bold text-gray-900 mb-4">📊 Cost Breakdown {results.length > 1 ? '(Best Option)' : ''}</h3>
                                            <div className="h-64">
                                                <ResponsiveContainer width="100%" height="100%">
                                                    <PieChart>
                                                        <Pie
                                                            data={pieData}
                                                            cx="50%"
                                                            cy="50%"
                                                            innerRadius={60}
                                                            outerRadius={80}
                                                            fill="#8884d8"
                                                            paddingAngle={5}
                                                            dataKey="value"
                                                        >
                                                            {pieData.map((entry, index) => (
                                                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                                            ))}
                                                        </Pie>
                                                        <Tooltip formatter={(value: number) => formatCurrency(value)} />
                                                        <Legend />
                                                    </PieChart>
                                                </ResponsiveContainer>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Phase 1: Business Intelligence Section */}
                                    <div className="mt-12">
                                        <div className="flex items-center gap-3 mb-6">
                                            <div className="bg-indigo-100 p-2 rounded-lg text-indigo-600">
                                                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
                                            </div>
                                            <h2 className="text-2xl font-bold text-gray-900 m-0">Business Intelligence {results.length > 1 ? '(Best Option)' : ''}</h2>
                                        </div>

                                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                                            {/* Market Intelligence Card */}
                                            <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                                                <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                                                    🌍 Market Intelligence
                                                </h3>
                                                
                                                <div className="space-y-4">
                                                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                                        <span className="text-sm text-gray-500 font-medium">Market Avg Price</span>
                                                        <span className="text-lg font-bold text-gray-900">{formatCurrency(results.find(r => r.id === (bestLocationId || results[0].id))!.metrics.marketInfo.avgPrice)}</span>
                                                    </div>
                                                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                                        <span className="text-sm text-gray-500 font-medium">Market Demand</span>
                                                        <span className="text-sm font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded">{results.find(r => r.id === (bestLocationId || results[0].id))!.metrics.marketInfo.demand}</span>
                                                    </div>
                                                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                                        <span className="text-sm text-gray-500 font-medium">Competition</span>
                                                        <span className="text-sm font-bold text-gray-700">{results.find(r => r.id === (bestLocationId || results[0].id))!.metrics.marketInfo.competition}</span>
                                                    </div>
                                                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                                        <span className="text-sm text-gray-500 font-medium">Market Volatility</span>
                                                        <div className="flex gap-1">
                                                            {[...Array(10)].map((_, i) => (
                                                                <div 
                                                                    key={i} 
                                                                    className={`w-1.5 h-4 rounded-full ${i < results.find(r => r.id === (bestLocationId || results[0].id))!.metrics.marketInfo.volatility ? 'bg-indigo-500' : 'bg-gray-200'}`}
                                                                />
                                                            ))}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            {/* Risk Analysis Card */}
                                            <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                                                <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                                                    🛡️ Risk Analysis
                                                </h3>
                                                
                                                <div className="flex flex-col items-center justify-center py-4">
                                                    <div className="relative w-32 h-32 flex items-center justify-center">
                                                        <svg className="w-full h-full transform -rotate-90">
                                                            <circle
                                                                cx="64"
                                                                cy="64"
                                                                r="56"
                                                                stroke="#E5E7EB"
                                                                strokeWidth="12"
                                                                fill="none"
                                                            />
                                                            <circle
                                                                cx="64"
                                                                cy="64"
                                                                r="56"
                                                                stroke={results.find(r => r.id === (bestLocationId || results[0].id))!.metrics.riskScore > 7 ? '#EF4444' : results.find(r => r.id === (bestLocationId || results[0].id))!.metrics.riskScore > 4 ? '#F59E0B' : '#10B981'}
                                                                strokeWidth="12"
                                                                fill="none"
                                                                strokeDasharray={351}
                                                                strokeDashoffset={351 - (351 * results.find(r => r.id === (bestLocationId || results[0].id))!.metrics.riskScore) / 10}
                                                                className="transition-all duration-1000 ease-out"
                                                            />
                                                        </svg>
                                                        <div className="absolute flex flex-col items-center">
                                                            <span className="text-3xl font-bold text-gray-900">{results.find(r => r.id === (bestLocationId || results[0].id))!.metrics.riskScore}/10</span>
                                                            <span className="text-xs text-gray-500 uppercase font-bold">Risk Score</span>
                                                        </div>
                                                    </div>
                                                    <p className="text-center text-sm text-gray-600 mt-4 px-4">
                                                        Based on profit margins, break-even time, and market volatility.
                                                    </p>
                                                </div>
                                            </div>

                                            {/* Price Comparison Chart */}
                                            <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                                                <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                                                    📊 Price Comparison
                                                </h3>
                                                <div className="h-64">
                                                    <ResponsiveContainer width="100%" height="100%">
                                                        <BarChart data={marketChartData}>
                                                            <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                                            <XAxis dataKey="name" tick={{fontSize: 12}} />
                                                            <YAxis tick={{fontSize: 12}} />
                                                            <Tooltip formatter={(value: number) => formatCurrency(value)} cursor={{fill: 'transparent'}} />
                                                            <Bar dataKey="price" radius={[4, 4, 0, 0]} barSize={60}>
                                                                {marketChartData.map((entry, index) => (
                                                                    <Cell key={`cell-${index}`} fill={entry.fill} />
                                                                ))}
                                                            </Bar>
                                                        </BarChart>
                                                    </ResponsiveContainer>
                                                </div>
                                            </div>
                                        </div>

                                        {/* AI Recommendations (Rule-Based) */}
                                        <div className="mt-8 bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-100 rounded-xl p-6">
                                            <h3 className="text-lg font-bold text-indigo-900 mb-4 flex items-center gap-2">
                                                💡 Strategic Recommendations
                                            </h3>
                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                {results.find(r => r.id === (bestLocationId || results[0].id))!.metrics.recommendations.map((rec, i) => (
                                                    <div key={i} className="flex gap-3 bg-white p-4 rounded-lg border border-indigo-100 shadow-sm">
                                                        <div className="text-indigo-500 mt-0.5">
                                                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                                                        </div>
                                                        <p className="text-gray-700 text-sm leading-relaxed">{rec}</p>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
