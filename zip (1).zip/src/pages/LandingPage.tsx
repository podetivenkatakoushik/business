import React, { useEffect, useState } from 'react';

interface LandingPageProps {
    onNavigate: (page: string) => void;
}

export default function LandingPage({ onNavigate }: LandingPageProps) {
    const [isScrolled, setIsScrolled] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            if (window.scrollY > 30) {
                setIsScrolled(true);
            } else {
                setIsScrolled(false);
            }
        };

        window.addEventListener('scroll', handleScroll, { passive: true });
        handleScroll();

        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    useEffect(() => {
        const observerOptions = {
            root: null,
            rootMargin: '0px 0px -40px 0px',
            threshold: 0.05
        };

        const fadeObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-visible');
                    fadeObserver.unobserve(entry.target);
                }
            });
        }, observerOptions);

        const animateElements = document.querySelectorAll(
            '.feature-card, .step-card, .testimonial-card, .preview-card'
        );

        animateElements.forEach((el, index) => {
            (el as HTMLElement).style.setProperty('--fade-delay', `${index * 0.08}s`);
            el.classList.add('fade-element');
            fadeObserver.observe(el);
        });

        // Fallback
        const timeout = setTimeout(() => {
            animateElements.forEach(el => {
                if (!el.classList.contains('fade-visible')) {
                    el.classList.add('fade-visible');
                }
            });
        }, 2000);

        return () => {
            fadeObserver.disconnect();
            clearTimeout(timeout);
        };
    }, []);

    const scrollToSection = (id: string) => {
        const element = document.getElementById(id);
        if (element) {
            const offset = 80;
            const top = element.getBoundingClientRect().top + window.pageYOffset - offset;
            window.scrollTo({ top, behavior: 'smooth' });
        }
        setIsMobileMenuOpen(false);
    };

    return (
        <>
            {/* ========== NAVBAR ========== */}
            <nav className={`navbar ${isScrolled ? 'scrolled' : ''}`} id="navbar">
                <div className="container navbar-inner">
                    <a href="#" onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="logo">
                        <svg className="logo-icon" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect width="32" height="32" rx="8" fill="url(#logo-grad)" />
                            <path d="M10 22V10h4l4 6 4-6h4v12h-4v-7l-4 5-4-5v7h-4z" fill="white" />
                            <defs>
                                <linearGradient id="logo-grad" x1="0" y1="0" x2="32" y2="32">
                                    <stop stopColor="#4F46E5" />
                                    <stop offset="1" stopColor="#7C3AED" />
                                </linearGradient>
                            </defs>
                        </svg>
                        <span>DecisionEngine</span>
                    </a>
                    <div className={`nav-links ${isMobileMenuOpen ? 'active' : ''}`} id="nav-links">
                        <a href="#features" onClick={(e) => { e.preventDefault(); scrollToSection('features'); }}>Features</a>
                        <a href="#how-it-works" onClick={(e) => { e.preventDefault(); scrollToSection('how-it-works'); }}>How It Works</a>
                        <a href="#testimonials" onClick={(e) => { e.preventDefault(); scrollToSection('testimonials'); }}>Testimonials</a>
                        <button onClick={() => onNavigate('dashboard')} className="btn btn-primary btn-sm">Get Started</button>
                    </div>
                    <button 
                        className={`mobile-menu-btn ${isMobileMenuOpen ? 'active' : ''}`} 
                        id="mobile-menu-btn" 
                        aria-label="Toggle menu"
                        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                    >
                        <span></span><span></span><span></span>
                    </button>
                </div>
            </nav>

            {/* ========== HERO ========== */}
            <section className="hero" id="hero">
                <div className="hero-bg-shapes">
                    <div className="hero-shape hero-shape-1"></div>
                    <div className="hero-shape hero-shape-2"></div>
                    <div className="hero-shape hero-shape-3"></div>
                </div>
                <div className="container hero-inner">
                    <div className="hero-badge">
                        <span className="badge">✨ Phase 0 — Free Profitability Calculator</span>
                    </div>
                    <h1 className="hero-title">Make Smarter <br /><span className="gradient-text">Business Decisions</span></h1>
                    <p className="hero-subtitle">Calculate product profitability, compare locations, and assess risk — all in one
                        powerful platform built for manufacturers and business owners.</p>
                    <div className="hero-ctas">
                        <button onClick={() => onNavigate('dashboard')} className="btn btn-primary btn-lg" id="hero-cta-primary">Get Started Free</button>
                        <a href="#features" onClick={(e) => { e.preventDefault(); scrollToSection('features'); }} className="btn btn-outline btn-lg" id="hero-cta-secondary">Learn More</a>
                    </div>
                    <div className="hero-stats">
                        <div className="hero-stat">
                            <span className="hero-stat-number">10K+</span>
                            <span className="hero-stat-label">Analyses Run</span>
                        </div>
                        <div className="hero-stat-divider"></div>
                        <div className="hero-stat">
                            <span className="hero-stat-number">500+</span>
                            <span className="hero-stat-label">Businesses Served</span>
                        </div>
                        <div className="hero-stat-divider"></div>
                        <div className="hero-stat">
                            <span className="hero-stat-number">50+</span>
                            <span className="hero-stat-label">Countries Supported</span>
                        </div>
                    </div>
                </div>
            </section>

            {/* ========== FEATURES ========== */}
            <section className="features" id="features">
                <div className="container">
                    <div className="section-header">
                        <span className="section-tag">Features</span>
                        <h2 className="section-title">Everything you need to evaluate profitability</h2>
                        <p className="section-subtitle">Powerful tools designed for small manufacturers and business owners to make
                            data-driven decisions.</p>
                    </div>
                    <div className="features-grid">
                        <div className="feature-card" id="feature-profit">
                            <div className="feature-icon feature-icon-blue">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <path d="M12 2v20M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6" />
                                </svg>
                            </div>
                            <h3>Profit Analysis</h3>
                            <p>Instantly calculate total cost, profit per unit, profit margins, and monthly revenue projections
                                from your inputs.</p>
                        </div>
                        <div className="feature-card" id="feature-location">
                            <div className="feature-icon feature-icon-purple">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z" />
                                    <circle cx="12" cy="10" r="3" />
                                </svg>
                            </div>
                            <h3>Location Comparison</h3>
                            <p>Compare profitability across up to 3 different locations side-by-side to find the most profitable
                                market.</p>
                        </div>
                        <div className="feature-card" id="feature-risk">
                            <div className="feature-icon feature-icon-emerald">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <path
                                        d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                                </svg>
                            </div>
                            <h3>Risk Assessment</h3>
                            <p>Get automatic risk level evaluation based on your profit margins — Low, Medium, or High — with
                                clear visual indicators.</p>
                        </div>
                        <div className="feature-card" id="feature-dashboard">
                            <div className="feature-icon feature-icon-amber">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <rect x="3" y="3" width="7" height="7" rx="1" />
                                    <rect x="14" y="3" width="7" height="7" rx="1" />
                                    <rect x="3" y="14" width="7" height="7" rx="1" />
                                    <rect x="14" y="14" width="7" height="7" rx="1" />
                                </svg>
                            </div>
                            <h3>Clean Dashboard</h3>
                            <p>View all your results in a beautifully designed dashboard with structured cards and clear visual
                                hierarchy.</p>
                        </div>
                        <div className="feature-card" id="feature-responsive">
                            <div className="feature-icon feature-icon-rose">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <rect x="5" y="2" width="14" height="20" rx="2" ry="2" />
                                    <line x1="12" y1="18" x2="12.01" y2="18" />
                                </svg>
                            </div>
                            <h3>Works Everywhere</h3>
                            <p>Fully responsive design that works seamlessly on desktop, tablet, and mobile devices.</p>
                        </div>
                        <div className="feature-card" id="feature-scale">
                            <div className="feature-icon feature-icon-cyan">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                    <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
                                    <polyline points="17 6 23 6 23 12" />
                                </svg>
                            </div>
                            <h3>Built to Scale</h3>
                            <p>Designed for future AI integration, database support, and advanced analytics as your business
                                grows.</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* ========== HOW IT WORKS ========== */}
            <section className="how-it-works" id="how-it-works">
                <div className="container">
                    <div className="section-header">
                        <span className="section-tag">How It Works</span>
                        <h2 className="section-title">Three simple steps to smarter decisions</h2>
                        <p className="section-subtitle">Get actionable profitability insights in under a minute.</p>
                    </div>
                    <div className="steps-grid">
                        <div className="step-card">
                            <div className="step-number">1</div>
                            <div className="step-connector"></div>
                            <h3>Enter Your Details</h3>
                            <p>Input your manufacturing cost, selling expenses, expected selling price, and target location
                                details.</p>
                        </div>
                        <div className="step-card">
                            <div className="step-number">2</div>
                            <div className="step-connector"></div>
                            <h3>Get Instant Analysis</h3>
                            <p>Our engine calculates profitability, margins, monthly projections, and risk levels in real time.
                            </p>
                        </div>
                        <div className="step-card">
                            <div className="step-number">3</div>
                            <h3>Make Your Decision</h3>
                            <p>Compare locations side-by-side and identify the most profitable opportunity for your business.
                            </p>
                        </div>
                    </div>
                </div>
            </section>

            {/* ========== PRODUCT PREVIEW ========== */}
            <section className="product-preview" id="product-preview">
                <div className="container">
                    <div className="section-header">
                        <span className="section-tag">Product Preview</span>
                        <h2 className="section-title">A dashboard designed for clarity</h2>
                        <p className="section-subtitle">Clean, intuitive interface that puts your most important metrics front and
                            center.</p>
                    </div>
                    <div className="preview-wrapper">
                        <div className="preview-card">
                            <img src="https://picsum.photos/1200/800?blur=1" alt="DecisionEngine Dashboard Preview" id="preview-image"
                                loading="lazy" referrerPolicy="no-referrer" />
                        </div>
                    </div>
                </div>
            </section>

            {/* ========== TESTIMONIALS ========== */}
            <section className="testimonials" id="testimonials">
                <div className="container">
                    <div className="section-header">
                        <span className="section-tag">Testimonials</span>
                        <h2 className="section-title">Loved by business owners</h2>
                        <p className="section-subtitle">See what manufacturers and entrepreneurs are saying about DecisionEngine.
                        </p>
                    </div>
                    <div className="testimonials-grid">
                        <div className="testimonial-card" id="testimonial-1">
                            <div className="testimonial-stars">★★★★★</div>
                            <p className="testimonial-quote">"DecisionEngine saved me weeks of spreadsheet work. I compared three
                                locations in minutes and found the most profitable one for my textile business."</p>
                            <div className="testimonial-author">
                                <div className="testimonial-avatar" style={{ background: 'linear-gradient(135deg, #4F46E5, #7C3AED)' }}>RK
                                </div>
                                <div>
                                    <div className="testimonial-name">Rajesh Kumar</div>
                                    <div className="testimonial-role">Textile Manufacturer, Mumbai</div>
                                </div>
                            </div>
                        </div>
                        <div className="testimonial-card" id="testimonial-2">
                            <div className="testimonial-stars">★★★★★</div>
                            <p className="testimonial-quote">"The risk assessment feature is incredibly valuable. It immediately
                                flags low-margin products so I can adjust my pricing strategy before launch."</p>
                            <div className="testimonial-author">
                                <div className="testimonial-avatar" style={{ background: 'linear-gradient(135deg, #059669, #10B981)' }}>SP
                                </div>
                                <div>
                                    <div className="testimonial-name">Sarah Patel</div>
                                    <div className="testimonial-role">FMCG Entrepreneur, London</div>
                                </div>
                            </div>
                        </div>
                        <div className="testimonial-card" id="testimonial-3">
                            <div className="testimonial-stars">★★★★★</div>
                            <p className="testimonial-quote">"Simple, clean, and effective. No bloatware, no unnecessary features —
                                just the profitability data I need to make confident decisions."</p>
                            <div className="testimonial-author">
                                <div className="testimonial-avatar" style={{ background: 'linear-gradient(135deg, #DC2626, #F59E0B)' }}>MA
                                </div>
                                <div>
                                    <div className="testimonial-name">Marco Alvarez</div>
                                    <div className="testimonial-role">Electronics Exporter, São Paulo</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* ========== BOTTOM CTA ========== */}
            <section className="bottom-cta" id="bottom-cta">
                <div className="container">
                    <div className="cta-card">
                        <h2>Ready to make smarter decisions?</h2>
                        <p>Start calculating profitability and comparing locations — completely free.</p>
                        <button onClick={() => onNavigate('dashboard')} className="btn btn-white btn-lg" id="bottom-cta-btn">Start Free Analysis →</button>
                    </div>
                </div>
            </section>

            {/* ========== FOOTER ========== */}
            <footer className="footer" id="footer">
                <div className="container">
                    <div className="footer-grid">
                        <div className="footer-brand">
                            <a href="#" onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="logo">
                                <svg className="logo-icon" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect width="32" height="32" rx="8" fill="url(#logo-grad-2)" />
                                    <path d="M10 22V10h4l4 6 4-6h4v12h-4v-7l-4 5-4-5v7h-4z" fill="white" />
                                    <defs>
                                        <linearGradient id="logo-grad-2" x1="0" y1="0" x2="32" y2="32">
                                            <stop stopColor="#4F46E5" />
                                            <stop offset="1" stopColor="#7C3AED" />
                                        </linearGradient>
                                    </defs>
                                </svg>
                                <span>DecisionEngine</span>
                            </a>
                            <p className="footer-desc">Empowering manufacturers and business owners to make data-driven decisions.
                            </p>
                        </div>
                        <div className="footer-col">
                            <h4>Product</h4>
                            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate('dashboard'); }}>Dashboard</a>
                            <a href="#features" onClick={(e) => { e.preventDefault(); scrollToSection('features'); }}>Features</a>
                            <a href="#how-it-works" onClick={(e) => { e.preventDefault(); scrollToSection('how-it-works'); }}>How It Works</a>
                        </div>
                        <div className="footer-col">
                            <h4>Company</h4>
                            <a href="#">About Us</a>
                            <a href="#">Careers</a>
                            <a href="#">Blog</a>
                        </div>
                        <div className="footer-col">
                            <h4>Legal</h4>
                            <a href="#">Privacy Policy</a>
                            <a href="#">Terms of Service</a>
                            <a href="#">Cookie Policy</a>
                        </div>
                    </div>
                    <div className="footer-bottom">
                        <p>&copy; 2026 DecisionEngine. All rights reserved.</p>
                    </div>
                </div>
            </footer>
        </>
    );
}
